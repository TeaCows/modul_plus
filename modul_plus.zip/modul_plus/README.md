# Modul+
**I DID NOT MAKE ANY OF THE MODUL MODS!** I JUST MADE THIS MODPACK!
## List of Mods and Their Authors
  - **Mods from [Meat_banono](https://h3vr.thunderstore.io/package/Meat_banono/)**
    - [Meats ModulAR](https://h3vr.thunderstore.io/package/Meat_banono/Meats_ModulAR/)
    - [Meats ModulAK](https://h3vr.thunderstore.io/package/Meat_banono/Meats_ModulAK/)
    - [Meats ModulSIG](https://h3vr.thunderstore.io/package/Meat_banono/Meats_ModulSIG/)
    - [Meats ModulShotguns](https://h3vr.thunderstore.io/package/Meat_banono/Meats_ModulShotguns/)
    - [Meats ModulSCAR](https://h3vr.thunderstore.io/package/Meat_banono/Meats_ModulSCAR/)
    - [Meats ModulDD](https://h3vr.thunderstore.io/package/Meat_banono/Meats_ModulDD/)
    - [Meats ModulAR10](https://h3vr.thunderstore.io/package/Meat_banono/Meats_ModulAR10/)
>
  - **Mods from [Not_Wolfie](https://h3vr.thunderstore.io/package/Not_Wolfie/)**
    - [Modul FAL](https://h3vr.thunderstore.io/package/Not_Wolfie/Modul_FAL/)
    - [Modul M700](https://h3vr.thunderstore.io/package/Not_Wolfie/Modul_M700/)
    - [Modul VAL](https://h3vr.thunderstore.io/package/Not_Wolfie/Modul_VAL/)
    - [Modul HK](https://h3vr.thunderstore.io/package/Not_Wolfie/Modul_HK/)
    - [Modul Kilo141](https://h3vr.thunderstore.io/package/Not_Wolfie/Modul_Kilo141/)
    - [Modul AR9](https://h3vr.thunderstore.io/package/Not_Wolfie/Modul_AR9/)
    - [Modul USP](https://h3vr.thunderstore.io/package/Not_Wolfie/Modul_USP/)
    - [Modul Bizon](https://h3vr.thunderstore.io/package/Not_Wolfie/Modul_Bizon/)
>
  - **Mods from [Andrew_FTW](https://h3vr.thunderstore.io/package/Andrew_FTW/)**
    - [FTW Arms Modular M1a](https://h3vr.thunderstore.io/package/Andrew_FTW/FTW_Arms_Modular_M1a/)
    - [FTW Arms Modular Addons](https://h3vr.thunderstore.io/package/Andrew_FTW/FTW_Arms_Modular_Addons/)
    - [FTW Arms Modular Vector](https://h3vr.thunderstore.io/package/Andrew_FTW/FTW_Arms_Modular_Vector/)
    - [FTW Arms Modular P226](https://h3vr.thunderstore.io/package/Andrew_FTW/FTW_Arms_Modular_P226/)
    - [FTW Arms and Meat Bananas Modular 870 Magfed
](https://h3vr.thunderstore.io/package/Andrew_FTW/FTW_Arms_and_Meat_Bananas_Modular_870_Magfed/)
>
  - **Mods from [Muzzle_Alt](https://h3vr.thunderstore.io/package/Muzzle_Alt/)**
    - [ModulBeowulf](https://h3vr.thunderstore.io/package/Muzzle_Alt/ModulBeowulf/)
    - [Modul Deagle](https://h3vr.thunderstore.io/package/Muzzle_Alt/Modul_Deagle/) 
>
  - **Mod from [sgtbrooks](https://h3vr.thunderstore.io/package/sgtbrooks/)**
    - [ModularHK417 and NightVision](https://h3vr.thunderstore.io/package/sgtbrooks/ModularHK417_and_NightVision/)
>
  - **Mod from [cityrobo](https://h3vr.thunderstore.io/package/cityrobo/)**
    - [modulXM8](https://h3vr.thunderstore.io/package/cityrobo/modulXM8/)
>
  - **Mods from [superpug](https://h3vr.thunderstore.io/package/superpug/)**
    - [ModulTT](https://h3vr.thunderstore.io/package/superpug/ModulTT/)
    - [ModulSKS](https://h3vr.thunderstore.io/package/superpug/ModulSKS/)
>
  - **Mods from [nayr31](https://h3vr.thunderstore.io/package/nayr31/)**
    - [modulSVD](https://h3vr.thunderstore.io/package/nayr31/modulSVD/)
    - [ModulSaiga12](https://h3vr.thunderstore.io/package/nayr31/ModulSaiga12/)
>
  - **Mods from [fsce](https://h3vr.thunderstore.io/package/fsce/)**
    - [Ashes ModulRPK16](https://h3vr.thunderstore.io/package/fsce/Ashes_ModulRPK16/)
    - [modultoz106](https://h3vr.thunderstore.io/package/fsce/modultoz106/)
>
  - **Mods from [Arpy](https://h3vr.thunderstore.io/package/Arpy/)**
    - [ModulGlock](https://h3vr.thunderstore.io/package/Arpy/ModulGlock/)
    - [KP15](https://h3vr.thunderstore.io/package/Arpy/KP15/)
    - [G3Tyaz](https://h3vr.thunderstore.io/package/Arpy/G3Tyaz/)
    - [ModulAR Sidecharging 65 Grendel Receiver](https://h3vr.thunderstore.io/package/Arpy/ModulAR_Sidecharging_65_Grendel_Receiver/)
    - [12.5 InchAr15](https://h3vr.thunderstore.io/package/Arpy/12_5_InchAr15/)
>
  - **Mod from [noghiri](https://h3vr.thunderstore.io/package/noghiri/)**
    - [BB ModulAR18](https://h3vr.thunderstore.io/package/noghiri/BB_ModulAR18/)
>
  - **Mods from [Muzzle](https://h3vr.thunderstore.io/package/noghiri/)**
    - [Remington 7615 Carbine](https://h3vr.thunderstore.io/package/Muzzle/Remington_7615_Carbine/)
    - [ModulAR Tube Handguards](https://h3vr.thunderstore.io/package/Muzzle/ModulAR_Tube_Handguards/)
    - [Remington RSASS](https://h3vr.thunderstore.io/package/Muzzle/Remington_RSASS/)
    - [ModulAKBeowulf](https://h3vr.thunderstore.io/package/Muzzle/ModulAKBeowulf/)
    - [ModulAR 57](https://h3vr.thunderstore.io/package/Muzzle/ModulAR_57/)
    - [ModulAK458](https://h3vr.thunderstore.io/package/Muzzle/ModulAK458/)
    - [Modul SW MP](https://h3vr.thunderstore.io/package/Muzzle/Modul_SW_MP/)
    - [Modul VR80](https://h3vr.thunderstore.io/package/Muzzle/Modul_VR80/)
>
  - **Mod from [Nuigo_Ftrmarket](https://h3vr.thunderstore.io/package/Nuigo_Ftrmarket/)**
    - [Krytac LMGE](https://h3vr.thunderstore.io/package/Nuigo_Ftrmarket/Krytac_LMGE/)
>
  - **Mod from [Chargin](https://h3vr.thunderstore.io/package/Chargin/)**
    - [ModulRevolver](https://h3vr.thunderstore.io/package/Chargin/ModulRevolver/)
>
  - **Mod from [Prime_Vr](https://h3vr.thunderstore.io/package/Prime_Vr/)**
    - [Modul Nagant](https://h3vr.thunderstore.io/package/Prime_Vr/Modul_Nagant/)
>
>
## **ENJOY!**